<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of iw
 *
 * @developer duongca
 */

if(!defined('IW_VC_PLG_PATH')){
    define('IW_VC_PLG_PATH', WP_PLUGIN_DIR.'/iw_composer_addons');
}